/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package coit11134_12195038.student;

/**
 *
 * @author goswa
 */
public class Student {

    private int studentID;
    private String fullName;
    private String campusEnrolled;
    private String courseCode;
    private int unitsCompleted;
    private int gpa;

    // Constructor
    public Student(int studentID, String fullName, String campusEnrolled, String courseCode, int unitsCompleted, int gpa) {
        this.studentID = studentID;
        this.fullName = fullName;
        this.campusEnrolled = campusEnrolled;
        this.courseCode = courseCode;
        this.unitsCompleted = unitsCompleted;
        this.gpa = gpa;
    }

    // Getters and Setters
    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCampusEnrolled() {
        return campusEnrolled;
    }

    public void setCampusEnrolled(String campusEnrolled) {
        this.campusEnrolled = campusEnrolled;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getUnitsCompleted() {
        return unitsCompleted;
    }

    public void setUnitsCompleted(int unitsCompleted) {
        this.unitsCompleted = unitsCompleted;
    }

    public int getGpa() {
        return gpa;
    }

    public void setGpa(int gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentID + ", Name: " + fullName + ", Campus: " + campusEnrolled
                + ", Course Code: " + courseCode + ", Units Completed: " + unitsCompleted + ", GPA: " + gpa;
    }
}
