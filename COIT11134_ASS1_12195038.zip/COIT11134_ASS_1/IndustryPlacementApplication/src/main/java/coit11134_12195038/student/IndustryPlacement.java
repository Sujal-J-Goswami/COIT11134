/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coit11134_12195038.student;

/**
 *
 * @author goswa
 */
import java.util.ArrayList;
import java.util.Scanner;

public class IndustryPlacement {

    // Constants for menu options
    final int ENTER_STUDENT = 1;
    final int VIEW_ALL_STUDENT = 2;
    final int EXIT = 3;

    // ArrayList to store Student objects
    private final ArrayList<Student> studentList = new ArrayList<>();

    // Method to display the menu and get the user's choice
    private int getMenuItem() {
        Scanner inputMenuChoice = new Scanner(System.in);

        System.out.println("\nPlease select from the following");
        System.out.println(ENTER_STUDENT + ". Enter student details");
        System.out.println(VIEW_ALL_STUDENT + ". View all students");
        System.out.println(EXIT + ". Exit the application");
        System.out.print("\nEnter choice ==> ");

        String choice = inputMenuChoice.nextLine();

        // Validate user input
        while (choice.equals("") || !isStringNumeric(choice)) {
            System.out.println("Error - Menu selection cannot be blank and must be numeric");
            System.out.print("Enter choice ==> ");
            choice = inputMenuChoice.nextLine();
        }

        return Integer.parseInt(choice);
    }

    // Check if a string is numeric
    private boolean isStringNumeric(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    // Validate campus input
    private boolean isCampusValid(String input) {
        return input.equalsIgnoreCase("CNS") || input.equalsIgnoreCase("ROK") ||
               input.equalsIgnoreCase("BNE") || input.equalsIgnoreCase("MEL") ||
               input.equalsIgnoreCase("SYD") || input.equalsIgnoreCase("Online");
    }

    // Validate course code input
    private boolean isCourseValid(String input) {
        return input.equalsIgnoreCase("CQ18") || input.equalsIgnoreCase("CG99") ||
               input.equalsIgnoreCase("CC53") || input.equalsIgnoreCase("CC54");
    }

    // Validate number of units completed and GPA
    private boolean isNumberValid(String input, int min, int max) {
        if (isStringNumeric(input)) {
            int inputInt = Integer.parseInt(input);
            return inputInt >= min && inputInt <= max;
        }
        return false;
    }

    // Main process handling method
    private void processOrders() {
        // Display welcome message
        System.out.println("Welcome to the Industry Placement Application");
        System.out.println("Author: [Sujal Goswami], Student ID: [12195038]");

        int choice = getMenuItem();

        while (choice != EXIT) {
            switch (choice) {
                case ENTER_STUDENT -> enterStudent();
                case VIEW_ALL_STUDENT -> viewAllStudent();
                default -> System.out.println("Error - Invalid menu choice");
            }
            choice = getMenuItem();
        }

        // Display exit message
        System.out.println("Thank you for using the Industry Placement Application.");
        System.out.println("Author: [Sujal Goswami], Student ID: [12195038], Date: [19-08-2024]");
    }

    // Method to enter student details
    private void enterStudent() {
        Scanner inText = new Scanner(System.in);

        // Validate and input student ID
        String input;
        int studentID;
        do {
            System.out.print("Please enter student ID (must be an 8-digit integer): ");
            input = inText.nextLine();
        } while (input.equals("") || !isStringNumeric(input) || input.length() != 8);

        studentID = Integer.parseInt(input);

        // Check if the student ID already exists
        if (findStudent(studentID) != -1) {
            System.out.println("Error - This student ID already exists.");
            return;
        }

        // Input and validate other student details
        System.out.print("Enter full name: ");
        String name = inText.nextLine();

        do {
            System.out.print("Enter campus enrolled (CNS, ROK, BNE, MEL, SYD, Online): ");
            input = inText.nextLine();
        } while (!isCampusValid(input));
        String campus = input;

        do {
            System.out.print("Enter course code (CQ18, CG99, CC53, CC54): ");
            input = inText.nextLine();
        } while (!isCourseValid(input));
        String courseCode = input;

        do {
            System.out.print("Enter units completed (1-24): ");
            input = inText.nextLine();
        } while (!isNumberValid(input, 1, 24));
        int unitsCompleted = Integer.parseInt(input);

        do {
            System.out.print("Enter GPA (0-7): ");
            input = inText.nextLine();
        } while (!isNumberValid(input, 0, 7));
        int gpa = Integer.parseInt(input);

        // Create a new Student object and add it to the list
        Student student = new Student(studentID, name, campus, courseCode, unitsCompleted, gpa);
        studentList.add(student);

        // Display the entered student information
        System.out.println("Student added successfully:");
        System.out.println(student);
    }

    // Method to find a student by ID
    private int findStudent(int id) {
        for (int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).getStudentID() == id) {
                return i;
            }
        }
        return -1;
    }

    // Method to view all students
    private void viewAllStudent() {
        if (studentList.isEmpty()) {
            System.out.println("No record found!");
        } else {
            for (Student student : studentList) {
                System.out.println(student);
            }
        }
    }

    // Main method
    public static void main(String[] args) {
        IndustryPlacement app = new IndustryPlacement();
        app.processOrders();
    }
}
